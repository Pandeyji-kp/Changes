import React, { useState } from 'react'
import Faqsection from './Faqsection'
import faqData from '../data/faq';

export default function Home() {


  const [allFaqs,setallFaqs] = useState(faqData);

  const [activeFaq,setactiveFaq] = useState(faqData[0].id);
  return (
    <>
      <div class="outer">
       {
        allFaqs.map((v,i)=>{
            return(<Faqsection value={v}  activeFaq={activeFaq}  setactiveFaq={setactiveFaq}/>)
        })
       }
       

      </div>
    </>
  )
}
